/*
2025002720 박주영
본인은 이 소스 파일을 다른 사람의 소스를 복사하지 않고 직접 작성하였습니다.
*/

#include <stdio.h>
#ifndef SELECTION_SORT_H
#define SELECTION_SORT_H
void sort(int list[], int n);
#endif
