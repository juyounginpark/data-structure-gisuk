#include <stdio.h>
#ifndef SELECTION_SORT_H
#define SELECTION_SORT_H
void sort(int list[], int n);
#endif
