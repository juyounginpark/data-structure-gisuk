#include <stdio.h>
void main(){
	puts("hi2");
}
